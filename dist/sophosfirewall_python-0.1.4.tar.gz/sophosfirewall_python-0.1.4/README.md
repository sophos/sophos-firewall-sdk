# Sophos Firewall Python SDK
This repository contains source code for a Sophos Firewall SDK that includes convenience methods for working with the Sophos Firewall XML API. 
  
For usage details please see the [documentation](https://super-adventure-p1qp7jm.pages.github.io/)

